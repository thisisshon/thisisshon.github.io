/**
 * Proofkit — framework-neutral runtime core config.
 *
 * Plain browser ES module. NOTHING here imports Astro, Vite, or any framework —
 * this is the portable heart the on-page overlay + both dashboards share, whether
 * they run inside an Astro build (via the .astro adapters) or as the standalone
 * core/*.html entries dropped into any stack.
 *
 * The Astro-facing config lives one level up in ../config.ts, which re-exports
 * everything here and adds the build-time concerns (SEO objects, the env-driven
 * Worker URL, the site-wide enable switch). Edit THIS file for tool data +
 * theming; edit ../config.ts for how it wires into a host project.
 */

/* --------------------------------------------------------------------------
 * Master switch (standalone/runtime layer).
 * In an Astro host the REAL switch is PROOFKIT_ENABLED in ../config.ts — the page
 * shims gate rendering on it, so when it is false the core never loads at all.
 * This flag is the equivalent guard for the non-Astro standalone entries.
 * ------------------------------------------------------------------------ */
export const PROOFKIT_ENABLED = true;

/* --------------------------------------------------------------------------
 * Cloudflare Worker base URL (shared comment store). Empty ⇒ localStorage demo.
 * Read from a global the host sets BEFORE this module evaluates:
 *   - Astro adapters inline `window.PROOFKIT_WORKER_URL` from the env var.
 *   - Standalone html sets the same global in a <script> before core/*.js loads.
 * ------------------------------------------------------------------------ */
export const WORKER_URL =
  (typeof window !== 'undefined' && window.PROOFKIT_WORKER_URL) || '';

/* --------------------------------------------------------------------------
 * Review password (client-side gate for no-Worker hosts). SHA-256 hex of the
 * plaintext, so the password never ships. Current value = SHA-256("website").
 * With the Worker deployed this is unused (the Worker enforces ADMIN_PASS).
 * ------------------------------------------------------------------------ */
export const REVIEW_PASSWORD_SHA256 =
  '747a8f398395dde8e524d9f983784bd8441c5cfe4307b5a079be5412ee65c314';

/** SHA-256 hex digest (Web Crypto — browsers + Workers). */
export async function sha256Hex(s) {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s));
  return Array.from(new Uint8Array(buf), (b) => b.toString(16).padStart(2, '0')).join('');
}

/** True when `input` is the review password (or when none is configured). */
export async function checkReviewPassword(input) {
  if (!REVIEW_PASSWORD_SHA256) return true; // blank => open
  return (await sha256Hex(input)) === REVIEW_PASSWORD_SHA256;
}

/* --------------------------------------------------------------------------
 * ONE login, adopted per tab. Every Proofkit surface — the on-page overlay,
 * /reviewdash, /teamdash — shares this single session: the { team, key } chosen at
 * the one login. The live session is per-tab (sessionStorage), but it is ALSO
 * mirrored into localStorage so a link opened in a NEW tab (which starts with an
 * empty sessionStorage — the browser will not copy it across `rel="noopener"`
 * links) can ADOPT it and skip a second login. Whoever logs in anywhere is
 * authenticated everywhere; the team decides the role (ADMIN_TEAM ⇒ admin panel,
 * else the team dashboard).
 * ------------------------------------------------------------------------ */
export function getSession() {
  try {
    let team = sessionStorage.getItem('pkTeam') || '';
    let key = sessionStorage.getItem('pkKey') || '';
    if (!key) {
      // Fresh tab (e.g. opened from a dashboard hyperlink): adopt the shared login
      // from a sibling tab so the user is not asked to sign in again.
      const lTeam = localStorage.getItem('pkTeam') || '';
      const lKey = localStorage.getItem('pkKey') || '';
      if (lKey) { team = lTeam; key = lKey; try { sessionStorage.setItem('pkTeam', team); sessionStorage.setItem('pkKey', key); } catch {} }
    }
    return { team, key };
  } catch { return { team: '', key: '' }; }
}
export function setSession(team, key) {
  try { sessionStorage.setItem('pkTeam', team); sessionStorage.setItem('pkKey', key); } catch {}
  try { localStorage.setItem('pkTeam', team); localStorage.setItem('pkKey', key); } catch {} // shared → adoptable by new tabs
}
export function clearSession() {
  try { sessionStorage.removeItem('pkTeam'); sessionStorage.removeItem('pkKey'); } catch {}
  try { localStorage.removeItem('pkTeam'); localStorage.removeItem('pkKey'); } catch {}
}

/* --------------------------------------------------------------------------
 * DEMO RESET (LOCAL/no-Worker mode only). The local domain now starts CLEAN so the
 * real review flow is testable from scratch — the old ~20-comment demo seed is
 * retired. Runs ONCE per browser (guarded by `pkDemoReset`): wipes any prior local
 * rows (old demo seed or otherwise) so an already-loaded tab clears too, then leaves
 * the store alone — comments you create afterwards persist. Never touches a Worker.
 * (To repopulate a demo dataset, restore this function from git history ≤ v2.16.0.)
 * ------------------------------------------------------------------------ */
export function ensureDemoReset() {
  try {
    if (typeof localStorage === 'undefined') return;
    if (localStorage.getItem('pkDemoReset') === '1') return; // clear once, then never again
    Object.keys(localStorage).forEach((k) => {
      if (k.indexOf('rvc:') === 0 || k === 'rvc-notifications' || k === 'pkDemoSeeded') localStorage.removeItem(k);
    });
    localStorage.setItem('pkDemoReset', '1');
  } catch {}
}

/* --------------------------------------------------------------------------
 * Ticket numbers. Every raised comment gets a human-facing ticket = YYMMDD (the
 * comment's own date) + a 4-digit per-day serial (0001–9999). e.g. a comment on
 * 2026-07-14 → 2607140001. The Worker owns the real counter (KV `ticketseq:<YYMMDD>`);
 * these helpers are for the no-Worker LOCAL demo and for FORMATTING on display.
 * ------------------------------------------------------------------------ */

/** Format a ticket string from an ISO timestamp + an integer serial. */
export function formatTicket(iso, serial) {
  const ymd = String(iso || '').slice(2, 10).replace(/-/g, '');      // "2026-07-14" -> "260714"
  const n = ((Math.max(1, serial | 0) - 1) % 9999) + 1;              // keep it in 1..9999
  return ymd + String(n).padStart(4, '0');
}

/** LOCAL-demo per-day serial: a localStorage counter mirroring the Worker's KV one. */
export function nextLocalTicket(iso) {
  const ymd = String(iso || '').slice(2, 10).replace(/-/g, '');
  const k = 'rvc-ticketseq:' + ymd;
  let seq = 1;
  try { seq = (parseInt(localStorage.getItem(k) || '0', 10) || 0) + 1; localStorage.setItem(k, String(seq)); } catch {}
  return formatTicket(iso, seq);
}

/* --------------------------------------------------------------------------
 * Teams + chip colours.
 * ------------------------------------------------------------------------ */
export const TEAMS = ['Product', 'SEO', 'Marketing', 'Content', 'Design', 'Business'];

/**
 * Login-only identity that maps to ADMIN; deliberately NOT in TEAMS.
 * 'Builder' is the admin who has access to EVERYTHING AND the default target team
 * a reviewer directs on-site changes to (see `toTeam`). Design is now an ordinary
 * team (it no longer maps to admin).
 */
export const ADMIN_TEAM = 'Builder';

/* --------------------------------------------------------------------------
 * TEAM ENABLEMENT — the ONE switch that gates which teams may use Proofkit.
 * Phase 1 ships with ONLY Content live; every other team is parked OFF (kept in
 * the codebase, NOT deleted). Re-enabling a team later is a SINGLE flag flip
 * here — flip its `false` to `true` and it lights up everywhere at once (login
 * dropdown, the sign-in guard, its dashboard route), no other edit needed. This
 * is the single source of truth every gate derives from — never hardcode a team
 * name to gate it elsewhere. Builder/ADMIN_TEAM is the admin identity and is
 * ALWAYS enabled (it is deliberately not listed here).
 * ------------------------------------------------------------------------ */
export const TEAM_ENABLED = {
  Content: true,
  Product: false,
  SEO: false,
  Marketing: false,
  Design: false,
  Business: false,
};

/** True when team `t` may use Proofkit. Builder (ADMIN_TEAM) is always enabled;
 *  an unknown/blank identity is treated as enabled (nothing to gate). */
export function isTeamEnabled(t) {
  if (t === ADMIN_TEAM) return true;
  return t in TEAM_ENABLED ? TEAM_ENABLED[t] : true;
}

/** The enabled subset of TEAMS (derived — never hand-maintain a second list). */
export const ENABLED_TEAMS = TEAMS.filter(isTeamEnabled);

/** Per-team chip colours as [background, text]. Keys must match TEAMS (+ ADMIN_TEAM,
 *  which is a directable target and so needs a chip too). */
export const TEAM_COLORS = {
  Product: ['#e7f0fb', '#1b5fa8'],
  SEO: ['#e7f7ee', '#1d7a46'],
  Marketing: ['#fdeee6', '#b5541f'],
  Content: ['#f1eafb', '#6b3fa0'],
  Design: ['#e4f5f3', '#0f6d64'],
  Business: ['#fce8ee', '#a12a4f'],
  Builder: ['#fbeeda', '#8a5a12'], // admin + default directed-to target (site changes)
};

/** Host-page elements to hide while review mode is armed. `[]` if nothing. */
export const HIDE_SELECTORS = ['.to-top'];

/* --------------------------------------------------------------------------
 * COMMENT VOCABULARY (v3 features 1/3/5/8) — the ONE shared source of truth for
 * comment types, their per-type template fields, reopen reasons, teamStatus →
 * token colours, and the one-line summary renderer. The overlay composer, both
 * dashboards, AND the demo store all import THESE (never re-declare the strings)
 * so a label/enum change is a single edit. Every consumer defaults gracefully
 * when a field is missing (the `|| ''` posture everything else here keeps).
 * ------------------------------------------------------------------------ */

/** The five comment types (Feature 1) as `{ value, label }`. `general` = the
 *  original freeform behaviour (zero regression); the other four swap the field
 *  set below. Order = the order the composer chips render in. */
export const COMMENT_TYPES = [
  { value: 'copy-fix', label: 'Copy fix' },
  { value: 'image-swap', label: 'Image swap' },
  { value: 'link-fix', label: 'Link fix' },
  { value: 'layout-tweak', label: 'Layout tweak' },
  { value: 'general', label: 'General' },
];

/**
 * Per-type template-field meta (Feature 1, §3). Keyed by commentType; each entry
 * is an ordered array of field descriptors the composer renders into
 * `record.templateFields`:
 *   { key, label, placeholder, autoFill, required, readOnly? }
 * - `autoFill` true ⇒ the overlay pre-fills it from the clicked element
 *   (`currentImage` from src/alt/selector, `currentUrl` from the <a> href) and
 *   shows it read-only. `general` carries no template fields (freeform textarea).
 * NOTE: `layout-tweak` + `image-swap` ALSO require the separate `expectedOutcome`
 * record field (Feature 8) — that lives on the record, not in templateFields, so
 * it is not listed here; see EXPECTED_OUTCOME_TYPES.
 */
export const TYPE_FIELDS = {
  'copy-fix': [
    { key: 'currentText', label: 'Current text', placeholder: 'The text as it reads now', autoFill: false, required: false },
    { key: 'newText', label: 'Change to', placeholder: 'The corrected text', autoFill: false, required: true },
  ],
  'image-swap': [
    { key: 'currentImage', label: 'Current image', placeholder: 'Auto-filled from the clicked image', autoFill: true, required: false, readOnly: true },
    { key: 'replacementDesc', label: 'Replacement', placeholder: 'Describe the image that should replace it', autoFill: false, required: true },
  ],
  'link-fix': [
    { key: 'currentUrl', label: 'Current URL', placeholder: 'Auto-filled from the clicked link', autoFill: true, required: false },
    { key: 'newUrl', label: 'New URL', placeholder: 'Where it should point', autoFill: false, required: true },
  ],
  'layout-tweak': [
    { key: 'whatToChange', label: 'What to change', placeholder: 'Describe the layout/spacing change', autoFill: false, required: true },
  ],
  'general': [],
};

/** Comment types that additionally require the `expectedOutcome` field (Feature 8),
 *  enforced client- + server-side. Derived once so no consumer hardcodes the set. */
export const EXPECTED_OUTCOME_TYPES = ['layout-tweak', 'image-swap'];

/** True when `commentType` needs an `expectedOutcome` (Feature 8). */
export function needsExpectedOutcome(commentType) {
  return EXPECTED_OUTCOME_TYPES.indexOf(commentType) !== -1;
}

/** Reopen reasons (Feature 3) as `{ value, label }` ×4 — the enum the reopen
 *  modal offers and the Worker validates. `other` additionally requires a note. */
export const REOPEN_REASONS = [
  { value: 'needs-clarification', label: 'Needs clarification' },
  { value: 'wrong-element', label: 'Wrong element' },
  { value: 'design-mismatch', label: 'Design mismatch' },
  { value: 'other', label: 'Other' },
];

/** Human label for a reopen-reason value ('' when unknown/blank). */
export function reopenReasonLabel(v) {
  const r = REOPEN_REASONS.find((x) => x.value === v);
  return r ? r.label : (v || '');
}

/** teamStatus → the `--pk-*` token that colours pins/badges (Feature 5). The value
 *  is the token NAME (no `var()`) so both `var(<name>)` and `getPropertyValue` work. */
export const STATUS_COLORS = {
  to_be_initiated: '--pk-amber',
  in_progress: '--pk-blue',
  deployed_live: '--pk-green',
  reopened: '--pk-softred',
};

/**
 * Render the one-line plain-text `summary` for a comment (Feature 1, §3). Shared by
 * the client (optimistic list line) AND the demo store (mirrors the Worker's
 * server-side render), so both produce identical text. Every field defaults when
 * missing; an empty typed summary falls back to the first 80 chars of the freeform
 * comment so a card is never blank.
 *   copy-fix:     "current → new"
 *   link-fix:     "old → new"
 *   image-swap:   "swap <currentImage>: <replacementDesc>"
 *   layout-tweak: "<whatToChange>"
 *   general:      first 80 chars of the comment
 */
export function renderSummary(commentType, templateFields, comment) {
  const f = templateFields || {};
  const s = (v) => String(v == null ? '' : v).trim();
  const arrow = (a, b) => { a = s(a); b = s(b); return a && b ? a + ' → ' + b : (a || b); };
  const fallback = () => s(comment).slice(0, 80);
  switch (commentType) {
    case 'copy-fix': return arrow(f.currentText, f.newText) || fallback();
    case 'link-fix': return arrow(f.currentUrl, f.newUrl) || fallback();
    case 'image-swap': {
      const img = s(f.currentImage) || 'image';
      const desc = s(f.replacementDesc);
      return (desc ? 'swap ' + img + ': ' + desc : 'swap ' + img) || fallback();
    }
    case 'layout-tweak': return s(f.whatToChange) || fallback();
    case 'general':
    default: return fallback();
  }
}

/* --------------------------------------------------------------------------
 * THEMING — --pk-* token skins + a runtime light/dark toggle.
 *
 * Each skin is a block of `--pk-*` custom properties. They used to inject once
 * under `:root{}` (baked, single skin). Now `themeCss()` emits every skin keyed
 * by `[data-pk-theme="…"]`, plus a `:root{}` default so first paint (before JS)
 * is already themed. Swapping the attribute on <html> re-skins live, and the
 * choice persists in localStorage — that is the whole light-mode toggle.
 * ------------------------------------------------------------------------ */
/* The full colour system (all three skins, keyed by [data-pk-theme]) now lives in
 * design/tokens.css — the single source of truth that the dashboards + the product
 * page link/import. This module only keeps the theme NAMES + the dark skin as a bare
 * literal for the ONE consumer that can't link a stylesheet: the on-page overlay,
 * which self-injects `:root{themeVars}` at review time so real visitors get nothing.
 * KEEP `themeVars` in sync with tokens.css :root (the Red Moon skin). */
export const DEFAULT_THEME = 'red-moon'; // dark default
export const LIGHT_THEME = 'light';      // what the toggle flips to
const THEME_KEY = 'pkTheme';              // localStorage cache — instant, no-flash first paint

/** Red Moon (dark) tokens as a bare declaration list — mirrors tokens.css :root. */
export const themeVars =
  '--pk-canvas:#181818;--pk-card:#1e1e1e;--pk-elev:#242424;--pk-input:#141414;' +
  '--pk-red:#da291c;--pk-red-2:#b01e0a;--pk-ink:#ffffff;--pk-body:#a7a7a7;' +
  '--pk-muted:#7d7d7d;--pk-hair:#333333;--pk-amber:#f5a623;--pk-green:#3ddc84;--pk-softred:#ef5b50';

/* The theme is a GLOBAL setting the admin controls — flipping it changes the mode
 * for everyone, so the source of truth is the Worker (KV `settings.theme`), not this
 * browser. localStorage is only a same-browser cache for instant no-flash paint and
 * the no-Worker demo fallback. Read path: everyone GETs /settings. Write path: only
 * the admin POSTs /settings (Worker enforces admin). */

/** Last-known theme from the local cache (fast, synchronous; falls back to dark). */
export function getTheme() {
  try { return localStorage.getItem(THEME_KEY) || DEFAULT_THEME; }
  catch { return DEFAULT_THEME; }
}

/** Apply a skin to THIS browser only: set the attribute, cache it, notify toggles. */
export function applyTheme(name) {
  document.documentElement.setAttribute('data-pk-theme', name);
  try { localStorage.setItem(THEME_KEY, name); } catch {}
  document.dispatchEvent(new CustomEvent('pk:themechange', { detail: { theme: name } }));
}

/** Admin action: set the GLOBAL theme — apply locally, then persist to the Worker
 *  (KV) so every other user picks it up. In demo mode (no Worker) it stays local. */
export async function setGlobalTheme(name) {
  applyTheme(name);
  if (!WORKER_URL) return;
  try {
    const pass = getSession().key || ''; // admin key = the shared session key (team === Builder)
    await fetch(WORKER_URL + '/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Review-Pass': pass },
      body: JSON.stringify({ theme: name }),
    });
  } catch {}
}

/** Pull the global theme from the Worker and apply it (falls back to the cache). */
export async function syncTheme() {
  if (!WORKER_URL) { document.documentElement.setAttribute('data-pk-theme', getTheme()); return getTheme(); }
  try {
    const r = await fetch(WORKER_URL + '/settings', { headers: { 'Content-Type': 'application/json' } });
    if (r.ok) { const j = await r.json(); const t = (j && j.theme) || getTheme(); applyTheme(t); return t; }
  } catch {}
  document.documentElement.setAttribute('data-pk-theme', getTheme());
  return getTheme();
}

/** Admin toggle: flip the GLOBAL theme between the light skin and the dark default. */
export function toggleTheme() {
  setGlobalTheme(getTheme() === LIGHT_THEME ? DEFAULT_THEME : LIGHT_THEME);
}

/** Individual (per-browser) toggle: flip the LOCAL theme only — never posted to the
 *  Worker, so it changes nobody else's mode. Team dashboards use this; the choice is
 *  cached by applyTheme (localStorage THEME_KEY), so it is remembered for the next
 *  login on this browser. Contrast toggleTheme(), which is the admin's GLOBAL flip. */
export function toggleLocalTheme() {
  applyTheme(getTheme() === LIGHT_THEME ? DEFAULT_THEME : LIGHT_THEME);
}

/** Individual theme init (team dashboards): apply the remembered local choice instantly
 *  and STOP — no global reconcile, no live push. Each browser keeps its own last-used
 *  mode across logins. Contrast initTheme(), which follows the admin's GLOBAL theme. */
export function initLocalTheme() {
  document.documentElement.setAttribute('data-pk-theme', getTheme());
  return getTheme();
}

/* Live push (SSE): subscribe to the Worker's /events stream so an admin's theme flip
 * lands on every open dashboard within ~a second — no reload, no tab-focus needed.
 * The Worker polls KV server-side and pushes `theme` events; EventSource auto-
 * reconnects when the bounded stream closes. Silent no-op without a Worker / SSE. */
let themeES = null;
export function startThemeStream() {
  if (!WORKER_URL || typeof EventSource === 'undefined' || themeES) return;
  try {
    themeES = new EventSource(WORKER_URL + '/events');
    themeES.addEventListener('theme', (e) => {
      try { const t = JSON.parse(e.data).theme; if (t && t !== getTheme()) applyTheme(t); } catch {}
    });
    // onerror: EventSource reconnects on its own; nothing to do here.
  } catch { themeES = null; }
}

/** Apply the cached theme instantly (no flash), reconcile with the global one, then
 *  live-subscribe (SSE) — with an on-focus sync as a belt-and-suspenders fallback. */
export function initTheme() {
  document.documentElement.setAttribute('data-pk-theme', getTheme()); // instant
  syncTheme();                                                        // reconcile with the Worker
  startThemeStream();                                                 // live push
  document.addEventListener('visibilitychange', () => { if (!document.hidden) syncTheme(); });
  return getTheme();
}

/* --------------------------------------------------------------------------
 * The light/dark toggle control. Its STYLES live in design/components.css
 * (`.pk-tt`); this only builds the wired DOM node, keeps it in sync with the
 * persisted theme, and flips the GLOBAL theme on click. Mounted under the admin
 * dashboard's wordmark via a [data-pk-toggle] slot (admin-only surface).
 * ------------------------------------------------------------------------ */

/** Build one toggle control (a wired DOM node). aria-checked === light mode.
 *  Pass { local:true } for the per-browser (team) flip; default is the admin GLOBAL flip. */
export function buildThemeToggle(opts) {
  const flip = (opts && opts.local) ? toggleLocalTheme : toggleTheme;
  const btn = document.createElement('button');
  btn.className = 'pk-tt';
  btn.type = 'button';
  btn.setAttribute('role', 'switch');
  btn.setAttribute('aria-label', 'Toggle light and dark theme');
  btn.innerHTML =
    '<span class="pk-tt-track"><span class="pk-tt-thumb">' +
    '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8Z"/></svg>' +
    '</span></span>';
  const sync = () => {
    const light = getTheme() === LIGHT_THEME;
    btn.setAttribute('aria-checked', String(light));
    btn.title = light ? 'Light mode — switch to dark' : 'Dark mode — switch to light';
  };
  btn.addEventListener('click', flip);
  document.addEventListener('pk:themechange', sync);
  sync();
  return btn;
}

/** Fill every `[data-pk-toggle]` slot on the page with a toggle control. Pass
 *  { local:true } to mount the per-browser (team) toggle instead of the global one. */
export function mountThemeToggle(selector, opts) {
  const slots = document.querySelectorAll(selector || '[data-pk-toggle]');
  slots.forEach((slot) => { if (!slot.firstChild) slot.appendChild(buildThemeToggle(opts)); });
}

/* --------------------------------------------------------------------------
 * buildDropdown — a custom, NON-NATIVE themed dropdown (styles: .pk-dropdown in
 * components.css). Sharp corners, spaced items, colour-themed via tokens.
 *   opts: { items:[{value?, label, onSelect?}], value, placeholder, fixedLabel,
 *           block, small, menuAlign:'right', onSelect(value,item) }
 *   fixedLabel → action menu (trigger label never changes, e.g. "Copy").
 * Returns { el, getValue, setValue, focus }.
 * ------------------------------------------------------------------------ */
const PK_CHEV =
  '<svg class="pk-dropdown-chev" viewBox="0 0 24 24" fill="none" stroke="currentColor" ' +
  'stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg>';

export function buildDropdown(opts) {
  opts = opts || {};
  const items = opts.items || [];
  const fixed = opts.fixedLabel || null;
  let value = opts.value != null ? opts.value : '';
  const wrap = document.createElement('div');
  wrap.className = 'pk-dropdown' + (opts.block ? ' pk-dropdown--block' : '') + (opts.small ? ' pk-dropdown--sm' : '');
  wrap.innerHTML =
    '<button type="button" class="pk-dropdown-trigger" aria-haspopup="listbox" aria-expanded="false">' +
      '<span class="pk-dropdown-label"></span>' + PK_CHEV +
    '</button>' +
    '<div class="pk-dropdown-menu' + (opts.menuAlign === 'right' ? ' pk-dropdown-menu--right' : '') + '" role="listbox"></div>';
  const trigger = wrap.querySelector('.pk-dropdown-trigger');
  const labelEl = wrap.querySelector('.pk-dropdown-label');
  const menu = wrap.querySelector('.pk-dropdown-menu');
  const valOf = (it) => (it.value != null ? it.value : it.label);
  const labelFor = (v) => { const it = items.find((i) => valOf(i) === v); return it ? it.label : ''; };
  const syncLabel = () => {
    if (fixed) { labelEl.textContent = fixed; labelEl.classList.remove('is-placeholder'); return; }
    if (value !== '' && value != null) { labelEl.textContent = labelFor(value); labelEl.classList.remove('is-placeholder'); }
    else { labelEl.textContent = opts.placeholder || 'Select'; labelEl.classList.add('is-placeholder'); }
  };

  let isOpen = false;
  const onDoc = (e) => { if (!wrap.contains(e.target)) close(); };
  const onKey = (e) => {
    if (e.key === 'Escape') { close(); trigger.focus(); return; }
    // Disabled items are inert — never a keyboard-focus stop.
    const list = [].slice.call(menu.querySelectorAll('.pk-dropdown-item:not([aria-disabled="true"])'));
    const i = list.indexOf(document.activeElement);
    if (e.key === 'ArrowDown') { e.preventDefault(); (list[i + 1] || list[0]).focus(); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); (list[i - 1] || list[list.length - 1]).focus(); }
  };
  function open() {
    isOpen = true; wrap.classList.add('is-open'); trigger.setAttribute('aria-expanded', 'true'); // CSS animates the menu in
    document.addEventListener('click', onDoc, true); document.addEventListener('keydown', onKey, true);
    const sel = menu.querySelector('[aria-selected="true"]') || menu.querySelector('.pk-dropdown-item:not([aria-disabled="true"])');
    if (sel) sel.focus();
  }
  function close() {
    isOpen = false; wrap.classList.remove('is-open'); trigger.setAttribute('aria-expanded', 'false'); // CSS animates the menu out
    document.removeEventListener('click', onDoc, true); document.removeEventListener('keydown', onKey, true);
  }
  trigger.addEventListener('click', (e) => { e.stopPropagation(); isOpen ? close() : open(); });

  items.forEach((it, idx) => {
    // A thin separator above this item (e.g. to fence Builder off from the teams).
    if (it.dividerBefore) { const sep = document.createElement('div'); sep.className = 'pk-dropdown-sep'; menu.appendChild(sep); }
    const v = valOf(it);
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'pk-dropdown-item'; b.setAttribute('role', 'option');
    b.dataset.value = v; b.style.setProperty('--i', idx); // stagger index for the open animation
    // Greyed, inert item (e.g. a team gated off via TEAM_ENABLED): visible but not
    // selectable — aria-disabled, out of the focus order, click is a no-op below.
    if (it.disabled) { b.setAttribute('aria-disabled', 'true'); b.tabIndex = -1; }
    if (it.icon) { const ico = document.createElement('span'); ico.className = 'pk-dropdown-ico'; ico.innerHTML = it.icon; b.appendChild(ico); }
    const txt = document.createElement('span'); txt.className = 'pk-dropdown-txt'; txt.textContent = it.label; b.appendChild(txt);
    if (!fixed && !it.disabled && v === value) b.setAttribute('aria-selected', 'true');
    b.addEventListener('click', () => {
      if (it.disabled) return; // inert — no value change, no onSelect
      if (!fixed) {
        value = v;
        menu.querySelectorAll('.pk-dropdown-item').forEach((e) => e.removeAttribute('aria-selected'));
        b.setAttribute('aria-selected', 'true');
        syncLabel();
      }
      close(); trigger.focus();
      if (it.onSelect) it.onSelect(v, it);
      if (opts.onSelect) opts.onSelect(v, it);
    });
    menu.appendChild(b);
  });

  syncLabel();
  return {
    el: wrap,
    getValue: () => value,
    setValue: (v) => {
      value = v;
      menu.querySelectorAll('.pk-dropdown-item').forEach((e) => {
        if (String(e.dataset.value) === String(v)) e.setAttribute('aria-selected', 'true'); else e.removeAttribute('aria-selected');
      });
      syncLabel();
    },
    setLabel: (t) => { labelEl.textContent = t; },
    focus: () => trigger.focus(),
  };
}

/* --------------------------------------------------------------------------
 * The shared "Panel Login" card — the ONE modern auth surface both dashboards
 * use (styles: design/components.css `.pk-login`). It builds the Team + Key
 * fields, the Authenticate button, and the ProofKit logo; each dashboard wires
 * its own submit (admin vs team routing). ADMIN_TEAM ('Builder') is offered as a
 * login-only identity — picking it + the admin key grants ADMIN access.
 * ------------------------------------------------------------------------ */
const PK_MARK =
  '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">' +
  '<path d="M4 5a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H9l-4 4V5Z" fill="var(--pk-red)"/>' +
  '<circle cx="12" cy="9.5" r="1.6" fill="#fff"/></svg>';

/** Build the shared login card. Returns { el, teamSel, keyInput, button, setError, setBusy }. */
export function buildPanelLogin(opts) {
  opts = opts || {};
  const title = opts.title || 'Panel Login';
  const sub = opts.sub || 'Enter your key to continue.';
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, (c) =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const el = document.createElement('div');
  el.className = 'pk-login';
  el.innerHTML =
    '<div class="pk-login-card" role="dialog" aria-modal="true">' +
      '<div class="pk-login-glow"></div>' +
      '<span class="pk-login-eyebrow">Content Review</span>' +
      '<h1 class="pk-login-title">' + esc(title) + '</h1>' +
      '<p class="pk-login-sub">' + esc(sub) + '</p>' +
      '<div class="pk-login-field">' +
        '<span class="pk-login-label">Team</span>' +
        '<div class="pk-login-team"></div>' +
      '</div>' +
      '<div class="pk-login-field">' +
        '<label class="pk-login-label" for="pk-login-key">Key</label>' +
        '<input id="pk-login-key" class="pk-login-input" type="password" placeholder="Enter your key" autocomplete="off" spellcheck="false" />' +
      '</div>' +
      '<div class="pk-login-err" hidden></div>' +
      '<button type="button" class="pk-login-btn">Authenticate</button>' +
      '<div class="pk-login-brand">' + PK_MARK + '<span>Proofkit</span></div>' +
    '</div>';
  const q = (s) => el.querySelector(s);
  // Team = a custom (non-native) dropdown, full-width inside the card.
  // Teams gated off via TEAM_ENABLED render greyed + inert; only enabled teams
  // (and Builder, always enabled) are pickable. One flag flip re-enables one.
  const teamItems = [...TEAMS].sort((a, b) => a.localeCompare(b)).map((t) => ({ value: t, label: t, disabled: !isTeamEnabled(t) }));
  // Builder (admin) sits last, fenced off from the ordinary teams by a divider.
  teamItems.push({ value: ADMIN_TEAM, label: ADMIN_TEAM, dividerBefore: true });
  const teamDD = buildDropdown({ items: teamItems, placeholder: 'Select Team', block: true });
  q('.pk-login-team').appendChild(teamDD.el);
  return {
    el,
    getTeam: () => teamDD.getValue(),
    setTeam: (t) => teamDD.setValue(t || ''),
    focusTeam: () => teamDD.focus(),
    keyInput: q('#pk-login-key'),
    button: q('.pk-login-btn'),
    setError: (msg) => { const e = q('.pk-login-err'); e.textContent = msg || ''; e.hidden = !msg; },
    setBusy: (busy, label) => {
      const b = q('.pk-login-btn'); b.disabled = !!busy; b.classList.toggle('is-busy', !!busy);
      if (label != null) b.textContent = label;
    },
  };
}

/* --------------------------------------------------------------------------
 * Friendly page names (dashboard link text). Project-configurable.
 * ------------------------------------------------------------------------ */
export const PAGE_NAMES = {
  '/': 'Home Page',
  '/about-us': 'About Us',
  '/open-demat-account': 'Open a Demat Account',
  '/become-a-partner': 'Become a Partner',
  '/karnataka-bank-customers': 'Karnataka Bank Customers',
  '/antara': 'Antara',
  '/sitemap': 'Sitemap',
  '/products': 'Product Suite',
  '/equity': 'Equity',
  '/derivatives': 'Derivatives',
  '/mtf': 'MTF',
  '/commodities': 'Commodities',
  '/currency': 'Currency',
  '/mutual-funds': 'Mutual Funds',
  '/etf': 'ETFs',
  '/ipo': 'IPO',
  '/nfo': 'NFO',
  '/nps': 'NPS',
  '/bonds': 'Bonds',
  '/fixed-deposit': 'Fixed Deposit',
  '/loan-against-mutual-fund': 'Loan Against Mutual Funds',
  '/loan-against-shares': 'Loan Against Securities',
  '/global-investing': 'Global Investing',
  '/research-hub': 'Research Centre',
  '/technical-analysis': 'Technical Research',
  '/fundamental-analysis': 'Fundamental Research',
  '/mutual-fund-analysis': 'Mutual Fund Research',
  '/calculators': 'Calculators',
  '/sip-calculator': 'SIP Calculator',
  '/lumpsum-calculator': 'Lumpsum Calculator',
  '/swp-calculator': 'SWP Calculator',
  '/nps-calculator': 'NPS Calculator',
  '/fd-calculator': 'FD Calculator',
  '/contact-us': 'Contact Us',
  '/grievance-redressal': 'Grievance Redressal',
  '/privacy-policy': 'Privacy Policy',
  '/terms-and-conditions': 'Terms & Conditions',
  '/terms-of-use-purse': 'Terms of Use – Purse',
  '/regulatorydocuments': 'Regulatory Documents',
  '/regulatorydocuments/investor-charter': 'Investor Charter',
  '/regulatorydocuments/mandatory-member-details': 'Mandatory Member Details',
  '/designsystem': 'Design System',
  '/designsystem/current': 'Design System – Current',
  '/designsystem/proposed': 'Design System – Proposed',
};

/** Friendly name for a page path (PAGE_NAMES, else a title-cased slug fallback). */
export function pageName(path) {
  const p = (path || '/').replace(/\/+$/, '') || '/';
  if (PAGE_NAMES[p]) return PAGE_NAMES[p];
  const seg = p.split('/').filter(Boolean).pop() || 'home';
  return seg.replace(/-/g, ' ').replace(/\b\w/g, (m) => m.toUpperCase());
}
