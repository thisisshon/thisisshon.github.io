# Proofkit 3.0 — upgrade bundle (in-place, data preserved)

Drop this into a project that **already has Proofkit** to upgrade it to 3.0 **in place**. Same URLs
(`/review`, `/reviewdash`, `/teamdash`), same storage keys, same Cloudflare KV — so **all existing
tickets are preserved** (records are backward-compatible; new fields default in). No new routes, no
new seams, no door button, no version suffix anywhere.

> **What 3.0 adds:** change-type templates · batch submit with a draft tray · reopen reason enums +
> notes · element screenshots · status-coloured pins · quick-question replies · duplicate-pin
> detection · required expected-outcome · group-by-page · code-location hints · team saved views ·
> insights/metrics — on top of the real-time review state machine.

---

## ⭐ If a Claude Code agent is doing this upgrade (paste this to it)

```
Upgrade this project's existing Proofkit to 3.0 from this bundle, IN PLACE. It's a drop-in
replacement — same routes, same storage keys, same worker/KV — so existing review data is preserved.

1. Read PORT-TO-PROJECT.md in this bundle.
2. Replace the contents of this project's src/plugins/proofkit/ with the bundle's
   src/plugins/proofkit/ — copy EVERYTHING EXCEPT worker/wrangler.toml. Do NOT overwrite the
   existing worker/wrangler.toml: it holds this project's KV namespace id, ALLOW_ORIGIN, and
   TEAM_KEYS, and keeping it is what preserves the existing tickets.
3. Do NOT change anything else. The route shims (src/pages/review.astro, reviewdash.astro,
   teamdash.astro), the shared-layout overlay line ({PROOFKIT_ENABLED && <ProofkitOverlay />}),
   and the /<page>/review block in 404.astro are UNCHANGED between versions and already correct.
   There is no door button and no *3 routes — if any exist from an earlier experiment, remove them.
4. Run the dev server and verify: /review, /reviewdash, /teamdash all load; sign-in works (in
   demo mode any key is accepted); the admin dashboard shows the new left-nav item "Insights".
5. Report exactly what files you changed, then tell me the ONE thing I must do myself: redeploy the
   worker to pick up the new backend (see step B below) — it needs my wrangler login.
```

The agent does steps 1–4. Only the worker redeploy (B) needs you.

---

## ⭐ If this is a FRESH project (no Proofkit yet) — paste this to the agent instead

```
Install Proofkit 3.0 fresh into this Astro project (it has no Proofkit yet). From this bundle:
1. Read PORT-TO-PROJECT.md and src/plugins/proofkit/INSTALL.md.
2. Copy the bundle's src/plugins/proofkit/ → this project's src/plugins/proofkit/ (whole folder).
3. Copy the bundle's src/pages/review.astro, reviewdash.astro, teamdash.astro → this project's
   src/pages/.
4. Wire the overlay into the shared layout (the file every page renders through, e.g.
   src/layouts/BaseLayout.astro): add to the frontmatter
     import ProofkitOverlay from '../plugins/proofkit/Overlay.astro';
     import { PROOFKIT_ENABLED } from '../plugins/proofkit/config';
   and near the end of the body
     {PROOFKIT_ENABLED && <ProofkitOverlay />}
   Adjust the ../ path if the layout sits at a different depth.
5. (Optional, static hosts) add the /<page>/review block from INSTALL.md to src/pages/404.astro so
   review arms on non-home pages.
6. Run the dev server and verify /review, /reviewdash, /teamdash load and sign-in works (demo mode:
   any key). The admin dashboard should show an "Insights" left-nav item.
7. Report what you changed, then tell me my manual steps: create a Cloudflare KV namespace, set
   ALLOW_ORIGIN to this site's real origin in worker/wrangler.toml, and wrangler deploy — these need
   my Cloudflare login and are the only things you can't do.
```

Fresh install needs MORE of your Cloudflare setup than an upgrade (a new KV + origin), because
there's no existing store to inherit. Demo mode still works with zero setup for testing.

---

## Manual steps (same as the agent's, if you're doing it by hand)

### A. Swap the package (preserves data)
Replace `src/plugins/proofkit/` with this bundle's `src/plugins/proofkit/`, **keeping your existing
`worker/wrangler.toml`** (copy everything except that one file). Nothing else changes — the routes,
route shims, the layout overlay line, and the 404 router are identical to your current install.

Test immediately: `npm run dev` → visit `/review`, `/reviewdash`, `/teamdash`. Until the worker is
redeployed (step B) it runs in **localStorage demo mode** (any key works) so you can click through
every new feature with no backend.

### B. Redeploy the worker (go-live; needs your Cloudflare)
The backend gained endpoints (`/image`, `/views`, `/metrics`), batch `POST /comments`, reopen-reason
validation, and reply notifications — all on the **same KV namespace**, so your existing
`page:` / `notifications` records are read as-is and simply gain the new fields lazily.

From `src/plugins/proofkit/worker/` (with your existing `wrangler.toml`):
```
wrangler deploy          # same worker name + same KV → existing tickets preserved
```
No new KV, no secret changes. Existing `ADMIN_PASS` / `TEAM_KEYS` / `ALLOW_ORIGIN` continue to work.
Then rebuild/redeploy the site so the new client bundles ship.

> Data note: one edge — reopen reasons created under the old version were free text; 3.0 uses a
> fixed reason set. Legacy free-text reasons still display as-is (they just aren't one of the new
> enum chips). Everything else carries over cleanly.

---

## Fresh install (no existing Proofkit)?
If the destination has **no** Proofkit at all, follow the package's own
`src/plugins/proofkit/INSTALL.md` instead — it covers adding the 3 route shims, the shared-layout
overlay line, the 404 block, and the `PUBLIC_REVIEW_WORKER_URL` env from scratch. The bundle's
`src/pages/` folder contains the three shims ready to copy for that case.

## Turn off / remove
- Off: set `PROOFKIT_ENABLED = false` in `src/plugins/proofkit/config.ts`.
- Remove: see `src/plugins/proofkit/REMOVAL.md`.
